# ClientApi

All URIs are relative to *https://virtserver.swaggerhub.com/JUANCARLOSVERDECORTE/ProjectBootcamp_43/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**allClient**](ClientApi.md#allClient) | **GET** /client/all | 
[**allClients**](ClientApi.md#allClients) | **GET** /client | 
[**getClientById**](ClientApi.md#getClientById) | **GET** /client/getClientById/{id} | 
[**saveClient**](ClientApi.md#saveClient) | **POST** /client/save | 

<a name="allClient"></a>
# **allClient**
> Client allClient()



returns all registered clients

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ClientApi;


ClientApi apiInstance = new ClientApi();
try {
    Client result = apiInstance.allClient();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ClientApi#allClient");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Client**](Client.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="allClients"></a>
# **allClients**
> List&lt;Client&gt; allClients()



returns all registered clients

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ClientApi;


ClientApi apiInstance = new ClientApi();
try {
    List<Client> result = apiInstance.allClients();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ClientApi#allClients");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;Client&gt;**](Client.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getClientById"></a>
# **getClientById**
> List&lt;Client&gt; getClientById(id)



return a especific client

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ClientApi;


ClientApi apiInstance = new ClientApi();
String id = "id_example"; // String | The Id of the client
try {
    List<Client> result = apiInstance.getClientById(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ClientApi#getClientById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| The Id of the client |

### Return type

[**List&lt;Client&gt;**](Client.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="saveClient"></a>
# **saveClient**
> Client saveClient(body)



This method create a new Client

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ClientApi;


ClientApi apiInstance = new ClientApi();
Client body = new Client(); // Client | create a new Client
try {
    Client result = apiInstance.saveClient(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ClientApi#saveClient");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Client**](Client.md)| create a new Client | [optional]

### Return type

[**Client**](Client.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

