# ClientProductApi

All URIs are relative to *https://virtserver.swaggerhub.com/JUANCARLOSVERDECORTE/ProjectBootcamp_43/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**allClientProduct**](ClientProductApi.md#allClientProduct) | **GET** /clientProduct | 
[**getClientProductById**](ClientProductApi.md#getClientProductById) | **GET** /clientProduct/getClientProductById/{id} | 
[**saveClientProduct**](ClientProductApi.md#saveClientProduct) | **POST** /clientProduct/save | 

<a name="allClientProduct"></a>
# **allClientProduct**
> List&lt;ClientProduct&gt; allClientProduct()



list all the client product relations

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ClientProductApi;


ClientProductApi apiInstance = new ClientProductApi();
try {
    List<ClientProduct> result = apiInstance.allClientProduct();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ClientProductApi#allClientProduct");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;ClientProduct&gt;**](ClientProduct.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getClientProductById"></a>
# **getClientProductById**
> ClientProduct getClientProductById(id)



Get a client product by id

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ClientProductApi;


ClientProductApi apiInstance = new ClientProductApi();
Integer id = 56; // Integer | 
try {
    ClientProduct result = apiInstance.getClientProductById(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ClientProductApi#getClientProductById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**|  |

### Return type

[**ClientProduct**](ClientProduct.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="saveClientProduct"></a>
# **saveClientProduct**
> ClientProduct saveClientProduct(body)



This method create a new Client-Product relation

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ClientProductApi;


ClientProductApi apiInstance = new ClientProductApi();
ClientProduct body = new ClientProduct(); // ClientProduct | create a new Client-Product
try {
    ClientProduct result = apiInstance.saveClientProduct(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ClientProductApi#saveClientProduct");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ClientProduct**](ClientProduct.md)| create a new Client-Product | [optional]

### Return type

[**ClientProduct**](ClientProduct.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

