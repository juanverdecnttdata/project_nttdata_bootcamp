# Client

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**idPerson** | **Integer** |  |  [optional]
**idClientType** | **Integer** |  |  [optional]
**status** | **Integer** |  |  [optional]
**creationDate** | **String** |  |  [optional]
**creationTerminal** | **String** |  |  [optional]
**modificationDate** | **String** |  |  [optional]
**modificationTerminal** | **String** |  |  [optional]
