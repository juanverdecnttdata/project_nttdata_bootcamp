# QueryBalance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idAccount** | **Integer** |  |  [optional]
**idClientProduct** | **Integer** |  |  [optional]
**balance** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
