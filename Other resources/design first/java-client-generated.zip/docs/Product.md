# Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**idProductType** | **Integer** |  |  [optional]
**name** | **String** |  |  [optional]
**status** | **Integer** |  |  [optional]
**startDate** | **String** |  |  [optional]
**creationDate** | **String** |  |  [optional]
**creationTerminal** | **String** |  |  [optional]
**modificationDate** | **String** |  |  [optional]
**modificationTerminal** | **String** |  |  [optional]
**comissionFreeMainteance** | **Integer** |  |  [optional]
**nMovements** | **Integer** |  |  [optional]
**nOperationMonth** | **Integer** |  |  [optional]
**freeMovements** | **Integer** |  |  [optional]
**amountMaintenance** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**freeOperationPerMonth** | **Integer** |  |  [optional]
