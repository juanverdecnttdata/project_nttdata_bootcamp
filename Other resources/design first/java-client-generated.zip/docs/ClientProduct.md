# ClientProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**idClient** | **Integer** |  |  [optional]
**idProduct** | **Integer** |  |  [optional]
**idAccount** | **Integer** |  |  [optional]
**creditLimit** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**credit** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**status** | **Integer** |  |  [optional]
**creationDate** | **String** |  |  [optional]
**creationTerminal** | **String** |  |  [optional]
**modificationDate** | **String** |  |  [optional]
**modificationTerminal** | **String** |  |  [optional]
