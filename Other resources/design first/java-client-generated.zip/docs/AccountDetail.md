# AccountDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**idAccount** | **Integer** |  |  [optional]
**idPerson** | **Integer** |  |  [optional]
**holder** | **Integer** |  |  [optional]
**authorizedSignature** | **Integer** |  |  [optional]
**status** | **Integer** |  |  [optional]
**creationDate** | **String** |  |  [optional]
**creationTerminal** | **String** |  |  [optional]
**modificationDate** | **String** |  |  [optional]
**modificationTerminal** | **String** |  |  [optional]
