# AccountHistory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**idAccount** | **Integer** |  |  [optional]
**idClientProduct** | **Integer** |  |  [optional]
**operationType** | **Integer** |  |  [optional]
**amount** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**status** | **Integer** |  |  [optional]
**creationDate** | **String** |  |  [optional]
**creationTerminal** | **String** |  |  [optional]
**modificationDate** | **String** |  |  [optional]
**modificationTerminal** | **String** |  |  [optional]
