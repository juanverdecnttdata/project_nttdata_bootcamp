# ProductApi

All URIs are relative to *https://virtserver.swaggerhub.com/JUANCARLOSVERDECORTE/ProjectBootcamp_43/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**allProduct**](ProductApi.md#allProduct) | **GET** /product/all | 
[**allProducts**](ProductApi.md#allProducts) | **GET** /product | 
[**getProductById**](ProductApi.md#getProductById) | **GET** /product/getProductById/{id} | 

<a name="allProduct"></a>
# **allProduct**
> Product allProduct()



returns all registered products

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductApi;


ProductApi apiInstance = new ProductApi();
try {
    Product result = apiInstance.allProduct();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductApi#allProduct");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Product**](Product.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="allProducts"></a>
# **allProducts**
> List&lt;Product&gt; allProducts()



returns all the products

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductApi;


ProductApi apiInstance = new ProductApi();
try {
    List<Product> result = apiInstance.allProducts();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductApi#allProducts");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;Product&gt;**](Product.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getProductById"></a>
# **getProductById**
> List&lt;Product&gt; getProductById(id)



returns a product by his id

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductApi;


ProductApi apiInstance = new ProductApi();
String id = "id_example"; // String | The Id of the product
try {
    List<Product> result = apiInstance.getProductById(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductApi#getProductById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| The Id of the product |

### Return type

[**List&lt;Product&gt;**](Product.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

