# PersonApi

All URIs are relative to *https://virtserver.swaggerhub.com/JUANCARLOSVERDECORTE/ProjectBootcamp_43/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**allPersons**](PersonApi.md#allPersons) | **GET** /person | 
[**getPersonById**](PersonApi.md#getPersonById) | **GET** /person/getPersonById/{id} | 
[**savePerson**](PersonApi.md#savePerson) | **POST** /person/save | 

<a name="allPersons"></a>
# **allPersons**
> List&lt;Person&gt; allPersons()



returns a all the persons registered

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PersonApi;


PersonApi apiInstance = new PersonApi();
try {
    List<Person> result = apiInstance.allPersons();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PersonApi#allPersons");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;Person&gt;**](Person.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getPersonById"></a>
# **getPersonById**
> Person getPersonById(id)



returns a person by his id

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PersonApi;


PersonApi apiInstance = new PersonApi();
Integer id = 56; // Integer | 
try {
    Person result = apiInstance.getPersonById(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PersonApi#getPersonById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**|  |

### Return type

[**Person**](Person.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="savePerson"></a>
# **savePerson**
> Person savePerson(body)



Create a new Person

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PersonApi;


PersonApi apiInstance = new PersonApi();
Person body = new Person(); // Person | a object with the format of person
try {
    Person result = apiInstance.savePerson(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PersonApi#savePerson");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Person**](Person.md)| a object with the format of person | [optional]

### Return type

[**Person**](Person.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

