# AccountApi

All URIs are relative to *https://virtserver.swaggerhub.com/JUANCARLOSVERDECORTE/ProjectBootcamp_43/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**allAccount**](AccountApi.md#allAccount) | **GET** /account | 
[**availableBalanceAccount**](AccountApi.md#availableBalanceAccount) | **POST** /account/availableBalanceAccount | 
[**availableClientProduct**](AccountApi.md#availableClientProduct) | **POST** /account/availableClientProduct | 
[**listMovements**](AccountApi.md#listMovements) | **POST** /account/listMovements | 
[**operation**](AccountApi.md#operation) | **POST** /account/operation | 
[**saveAccount**](AccountApi.md#saveAccount) | **POST** /account/save | 

<a name="allAccount"></a>
# **allAccount**
> List&lt;Account&gt; allAccount()



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AccountApi;


AccountApi apiInstance = new AccountApi();
try {
    List<Account> result = apiInstance.allAccount();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccountApi#allAccount");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;Account&gt;**](Account.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="availableBalanceAccount"></a>
# **availableBalanceAccount**
> QueryBalance availableBalanceAccount(body)



Get a object with the balance of an account

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AccountApi;


AccountApi apiInstance = new AccountApi();
Account body = new Account(); // Account | Account
try {
    QueryBalance result = apiInstance.availableBalanceAccount(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccountApi#availableBalanceAccount");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Account**](Account.md)| Account | [optional]

### Return type

[**QueryBalance**](QueryBalance.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="availableClientProduct"></a>
# **availableClientProduct**
> QueryBalance availableClientProduct(body)



Get a object with the credit of an client product

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AccountApi;


AccountApi apiInstance = new AccountApi();
Account body = new Account(); // Account | Account
try {
    QueryBalance result = apiInstance.availableClientProduct(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccountApi#availableClientProduct");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Account**](Account.md)| Account | [optional]

### Return type

[**QueryBalance**](QueryBalance.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="listMovements"></a>
# **listMovements**
> AccountHistory listMovements(body)



Get all the movements of a account

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AccountApi;


AccountApi apiInstance = new AccountApi();
Account body = new Account(); // Account | Account
try {
    AccountHistory result = apiInstance.listMovements(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccountApi#listMovements");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Account**](Account.md)| Account | [optional]

### Return type

[**AccountHistory**](AccountHistory.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="operation"></a>
# **operation**
> Message operation(body)



Calculates deposit, withdrawal, payment or loading money to an account

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AccountApi;


AccountApi apiInstance = new AccountApi();
Account body = new Account(); // Account | Account
try {
    Message result = apiInstance.operation(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccountApi#operation");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Account**](Account.md)| Account | [optional]

### Return type

[**Message**](Message.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="saveAccount"></a>
# **saveAccount**
> Account saveAccount(body)



This method create a new account

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AccountApi;


AccountApi apiInstance = new AccountApi();
Account body = new Account(); // Account | create a new account
try {
    Account result = apiInstance.saveAccount(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccountApi#saveAccount");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Account**](Account.md)| create a new account | [optional]

### Return type

[**Account**](Account.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

