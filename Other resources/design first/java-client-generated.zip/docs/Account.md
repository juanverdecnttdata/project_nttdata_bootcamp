# Account

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**idClient** | **Integer** |  |  [optional]
**status** | **Integer** |  |  [optional]
**creationDate** | **String** |  |  [optional]
**creationTerminal** | **String** |  |  [optional]
**modificationDate** | **String** |  |  [optional]
**modificationTerminal** | **String** |  |  [optional]
**accountDetail** | [**List&lt;AccountDetail&gt;**](AccountDetail.md) |  |  [optional]
