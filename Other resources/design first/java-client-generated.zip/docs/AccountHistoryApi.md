# AccountHistoryApi

All URIs are relative to *https://virtserver.swaggerhub.com/JUANCARLOSVERDECORTE/ProjectBootcamp_43/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**allAccountHistory**](AccountHistoryApi.md#allAccountHistory) | **GET** /accountHistory | 
[**listAccountHistoryByAccount**](AccountHistoryApi.md#listAccountHistoryByAccount) | **POST** /accountHistory/listAccountHistoryByAccount | 
[**listAccountHistoryByClientProduct**](AccountHistoryApi.md#listAccountHistoryByClientProduct) | **POST** /accountHistory/listAccountHistoryByClientProduct | 
[**saveAccountHistory**](AccountHistoryApi.md#saveAccountHistory) | **POST** /accountHistory/save | 

<a name="allAccountHistory"></a>
# **allAccountHistory**
> List&lt;AccountHistory&gt; allAccountHistory()



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AccountHistoryApi;


AccountHistoryApi apiInstance = new AccountHistoryApi();
try {
    List<AccountHistory> result = apiInstance.allAccountHistory();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccountHistoryApi#allAccountHistory");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;AccountHistory&gt;**](AccountHistory.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="listAccountHistoryByAccount"></a>
# **listAccountHistoryByAccount**
> AccountHistory listAccountHistoryByAccount(body)



This method list all account history with relation from account object

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AccountHistoryApi;


AccountHistoryApi apiInstance = new AccountHistoryApi();
Account body = new Account(); // Account | List all account history from account object
try {
    AccountHistory result = apiInstance.listAccountHistoryByAccount(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccountHistoryApi#listAccountHistoryByAccount");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Account**](Account.md)| List all account history from account object | [optional]

### Return type

[**AccountHistory**](AccountHistory.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="listAccountHistoryByClientProduct"></a>
# **listAccountHistoryByClientProduct**
> AccountHistory listAccountHistoryByClientProduct(body)



This method list all account history with relation from client-product object

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AccountHistoryApi;


AccountHistoryApi apiInstance = new AccountHistoryApi();
Account body = new Account(); // Account | List all account history from client-product object
try {
    AccountHistory result = apiInstance.listAccountHistoryByClientProduct(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccountHistoryApi#listAccountHistoryByClientProduct");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Account**](Account.md)| List all account history from client-product object | [optional]

### Return type

[**AccountHistory**](AccountHistory.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="saveAccountHistory"></a>
# **saveAccountHistory**
> AccountHistory saveAccountHistory(body)



This method create a new Account History

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AccountHistoryApi;


AccountHistoryApi apiInstance = new AccountHistoryApi();
AccountHistory body = new AccountHistory(); // AccountHistory | create a new AccountHistory
try {
    AccountHistory result = apiInstance.saveAccountHistory(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AccountHistoryApi#saveAccountHistory");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AccountHistory**](AccountHistory.md)| create a new AccountHistory | [optional]

### Return type

[**AccountHistory**](AccountHistory.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

